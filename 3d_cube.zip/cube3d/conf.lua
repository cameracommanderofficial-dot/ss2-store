function love.conf(t)
  t.identity = "cube3d"
  t.window.title = "3D Cube Demo"
  t.window.width, t.window.height = 960, 540
  t.window.depth = 16
end