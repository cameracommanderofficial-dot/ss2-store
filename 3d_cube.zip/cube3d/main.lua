local g3d = require "g3d"

-- model file, texture, position {x,y,z}, rotation, scale {x,y,z}
local cube = g3d.newModel("assets/cube.obj", "assets/texture.png", {0, 0, 0}, nil, {1, 1, 1})
local t = 0

function love.load()
  love.mouse.setRelativeMode(true)
  love.graphics.setBackgroundColor(0.15, 0.15, 0.25)   -- dark blue, so a black cube would still show
  love.graphics.setMeshCullMode("none")                -- draw both sides of every face
  g3d.camera.lookAt(0, 0, 6, 0, 0, 0)                  -- camera at z=6, looking at the cube at the center
end

function love.update(dt)
  t = t + dt
  cube:setRotation(t * 0.6, t, 0)
  g3d.camera.firstPersonMovement(dt)                   -- WASD to move, Space / Shift for up and down
  if love.keyboard.isDown("escape") then love.event.quit() end
end

function love.mousemoved(x, y, dx, dy)
  g3d.camera.firstPersonLook(dx, dy)
end

function love.draw()
  cube:draw()
  love.graphics.print("If you can read this, the game is running. WASD + mouse to look around.", 10, 10)
end